import { ApiProperty } from "@nestjs/swagger";

export class demoDto {

    @ApiProperty()
    value: String;
}
