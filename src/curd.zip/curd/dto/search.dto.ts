import { ApiProperty } from "@nestjs/swagger";

export class searchDto {

    @ApiProperty()
    value: String;
}
