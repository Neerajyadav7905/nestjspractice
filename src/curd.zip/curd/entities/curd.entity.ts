export class Curd {}
